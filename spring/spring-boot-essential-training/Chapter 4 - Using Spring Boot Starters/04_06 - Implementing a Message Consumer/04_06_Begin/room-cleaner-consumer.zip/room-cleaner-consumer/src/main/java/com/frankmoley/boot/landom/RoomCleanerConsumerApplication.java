package com.frankmoley.boot.landom;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RoomCleanerConsumerApplication {

	public static void main(String[] args) {
		SpringApplication.run(RoomCleanerConsumerApplication.class, args);
	}

}

